package com.example.Supplements;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplementsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplementsApplication.class, args);
	}

}
