package com.example.Supplements.entity;

import jakarta.annotation.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Users")
public class Users {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String FirstName;
	private String LastName;
	
	private String Email;
	private String Password;
	private String UserName;
	private long PhoneNo;
	
	public String getFirstName() {
		return FirstName;
	}
	@Column(name="First_Name")
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	@Column(name="First_Name")
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getEmail() {
		return Email;
	}
	@Column(name="First_Name")
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	@Column(name="First_Name")
	public void setPassword(String password) {
		Password = password;
	}
	

}
