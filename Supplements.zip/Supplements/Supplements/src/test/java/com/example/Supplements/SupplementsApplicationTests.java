package com.example.Supplements;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplementsApplicationTests {

	@Test
	void contextLoads() {
	}

}
